<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Models\CustomerModel;
use App\Models\AssessmentUserModel;
use App\Services\Business\SecurityService;

class AssessmentController extends Controller
{
    // to obtain an instance of the current HTTP request from a post
    public function index(Request $request)
    {
        // Create a user model with username and password
        // the properties come from the assessment view form in the inputs
      $userData = new AssessmentUserModel(request()->get('username'), request()->get('password'), request()->get('phoneNumber'), request()->get('fullName'));  
        
        // Put all the form values in an array called 'formValues'
        $formValues = $request->all();
        // Get just the username from the form
        $username = request()->get('username');
        // Get the password
        $password = request()->get('password');
        // Get the phoneNumber
        $phoneNumeber = request()->get('phoneNumber');
        // Get the fullName
        $fullName = request()->get('fullName');   
        
        // Input into model
        $username= request()->input('username');
        $password = request()->input('password');
        $phoneNumeber = request()->input('phoneNumber');
        $fullName = request()->input('fullName'); 
        return $request->all(); // Return all data
    }    
    
    // Validation added for Activity3
    private function validateForm(Request $request)
    {
        // Setup Data Validatoin Rules for Login Form
        $rules = ['user_name'=> 'Required | Between: 4, 10 | Alpha',
                    'password' => 'Required | Between: 4, 10'];
        // Run Data Validation Rules
        $this->validate($request, $rules);
    }
    
}