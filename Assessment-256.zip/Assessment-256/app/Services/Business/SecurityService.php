<?php
namespace App\Services\Business;

use App\Models\AssessmentUserModel;
use App\Models\UserModel;
use App\Models\CustomerModel;
use App\Services\Data\SecurityDAO;
use App\Services\Data\CustomerDAO;
use App\Services\Data\OrderDAO;
use App\Services\Data\Utility\DBConnect;
class SecurityService 
{
    // Define the properties
    private $verifyCred;
    // Method that will pass credentials to the DA Layer
    public function login(AssessmentUserModel $credentials)
    {
        // Instantiate the Data Access Layer so we have access to its methods.
        $this->verifyCred = new SecurityDAO();
        
        // Return true or false by passing the credentials
        // To the object
        return $this->verifyCred->findByUser($credentials);
    }
    
}