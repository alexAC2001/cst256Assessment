<?php
namespace App\Services\Data;

use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class OrderDAO
{
    // Define the connection string
    private $conn;
    private $dbname = "activity3";
    private $dbQuery;
    private $connection;
    private $dbObj;
    
    // Constructor that creates a connection with the database
    public function __construct($dbObj)
    {
        $this->dbObj =$dbObj;
    }
    
    /*
     * Method to add a new order
     */
    public function addOrder(string $product, int $customerID)
    {
        try
        {
            // Define the query to search the database for the credentials
            $this->dbQuery = @"INSERT INTO `order`
                              (Product, CustomerID)
                              VALUES
                              ('" . $product . "', " . $customerID . ")"; // Single quote needed for strings
            // If the selected query returns a resultset
            //$result = mysqli_query($this->conn, $this->dbQuery);
            // If there are rows that are returned we have valid credentials
            echo $this->dbQuery;
            if($this->dbObj->query($this->dbQuery))
            {
                //$this->conn->closeDbConnect();
                return true; // Success
            }
            else
            {
                //$this->conn->closeDbConnect();
                return false; // Faliure
            }
            
        } catch(Exception $e)
        {
            echo $e->getMessage();
        }
    }
    
    // ACID 
    // Get the next ID for the PK to put in the FK    
    public function getNextID()
    {
        try 
        {
            // Define the query to get the nxt ID
            $this->dbQuery = "SELECT CustomerID
                              FROM customer
                              ORDER BY CustomeID DESC LIMIT 0,1";
            
            $result = $this->dbObj->query($this->query);
            while ($row = mysqli_fetch_array($result))
            {
                return $row['CustomerID'] + 1; // Getting the LAST CustomerID
            }            
        } 
        catch (Exception $e) 
        {
            echo $e->getMessage();
        }
    }
    
    
}