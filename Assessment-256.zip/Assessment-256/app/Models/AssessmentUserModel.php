<?php 
namespace App\Models;
// Model with four properties 
class AssessmentUserModel 
{
    // Properies set
    private $username;
    private $password;
    private $phoneNumber;
    private $fullName;
    
    // Class Constructor
    public function __construct($username, $password, $phoneNumber, $fullName)
    {
        $this->username = $username;
        $this->password = $password;
        $this->phoneNumber = $phoneNumber;
        $this->fullName = $fullName;
    }       
     // Getter Method -> username
    public function getUsername()
    {
        return $this->username;
    }
     // Getter Method -> password
    public function getPassword()
    {
        return $this->password;
    }    
     // Getter Method -> phonenumber
    public function getPhoneNumber()
    {
        return $this->phoneNumber;
    }
     // Getter Method -> fullname
    public function getFullName()
    {
        return $this->fullName;
    }
}