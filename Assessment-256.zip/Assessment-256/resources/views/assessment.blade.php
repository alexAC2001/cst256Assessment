<html>
	<head>
		<title>Assessment-256</title>
	</head>
	<body>
		<div>
			<form action="adduser" method="post">
				{{ csrf_field() }}
				<!--  Begin Demo Table -->
				<div class="demo-table">
					<div class="form-head">Four Input Fields</div>
					<!-- Begin Username -->
					<div class="field-column">
						<div>
							<label for="username">Input 1</label><span id="username_info" class="error-info"></span>						
						</div>
						<div>
							<input name="username" id="username" type="text" class="demo-input-box">
						</div>					
				</div>
				<!-- End Username -->
				<!-- Begin Password -->
					<div class="field-column">
						<div>
							<label for="password">Input 2</label><span id="password_info" class="error-info"></span>						
						</div>
						<div>
							<input name="password" id="password" type="text" class="demo-input-box">
						</div>					
				</div>
				<div class="field-column">
						<div>
							<label for="phoneNumber">Input 3</label><span id="phoneNumber_info" class="error-info"></span>						
						</div>
						<div>
							<input name="phoneNumber" id="phoneNumber" type="text" class="demo-input-box">
						</div>					
				</div>
				<div class="field-column">
						<div>
							<label for="fullName">Input 4</label><span id="fullName_info" class="error-info"></span>						
						</div>
						<div>
							<input name="fullName" id="fullName" type="text" class="demo-input-box">
						</div>					
				</div>
				<!-- End Password -->
				</div>
				<!--  End Demo Table -->
				<div class="field-column">
					<input type="submit" class="btnLogin">
				</div>				
			</form>	
		</div>
	</body>
</html>