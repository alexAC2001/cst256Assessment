<html land="en">
	<head>
		<title>Welcome</title>	
	</head>
	<body>
		<div align="center">
		<h1>Welcome to Activity 3</h1>
		</div>
	</body>
</html>